#!/bin/sh
cp commit-msg ../.git/hooks/commit-msg
chmod +x ../.git/hooks/commit-msg